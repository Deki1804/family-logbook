package com.familylogbook.app.data.notification

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.familylogbook.app.data.repository.FirestoreLogbookRepository
import com.familylogbook.app.data.repository.InMemoryLogbookRepository
import com.familylogbook.app.domain.repository.LogbookRepository
import kotlinx.coroutines.flow.first

/**
 * Background worker that checks for medicine and service reminders and shows notifications.
 * This worker runs periodically to check for upcoming reminders.
 */
class ReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    private val notificationManager = NotificationManager(applicationContext)
    
    override suspend fun doWork(): Result {
        return try {
            // Get repository - get userId from shared preferences
            val sharedPrefs = applicationContext.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            val userId = sharedPrefs.getString("user_id", null)
            
            val repository: LogbookRepository = if (userId != null) {
                try {
                    FirestoreLogbookRepository(userId = userId)
                } catch (e: Exception) {
                    InMemoryLogbookRepository()
                }
            } else {
                InMemoryLogbookRepository()
            }
            
            val now = System.currentTimeMillis()
            val oneDayInMillis = 24 * 60 * 60 * 1000L
            val oneHourInMillis = 60 * 60 * 1000L
            
            // Get all entries
            val entries = repository.getAllEntries().first()
            
            entries.forEach { entry ->
                // Check medicine reminders
                entry.nextMedicineTime?.let { nextTime ->
                    val timeUntilNext = nextTime - now
                    // Show notification if it's time (within 5 minutes) or overdue
                    if (timeUntilNext <= 5 * 60 * 1000L && timeUntilNext >= -30 * 60 * 1000L) {
                        val personName = entry.personId?.let { 
                            // Try to get person name - for now just use entry text
                            null // TODO: Fetch person name from repository
                        }
                        notificationManager.showMedicineReminder(
                            medicineName = entry.medicineGiven ?: "Medicine",
                            personName = personName,
                            notificationId = entry.id.hashCode()
                        )
                    }
                }
                
                // Check service/appointment reminders
                entry.reminderDate?.let { reminderDate ->
                    val timeUntilReminder = reminderDate - now
                    
                    // Show notification 1 day before
                    if (timeUntilReminder > 0 && timeUntilReminder <= oneDayInMillis && 
                        timeUntilReminder > oneDayInMillis - oneHourInMillis) {
                        notificationManager.showServiceReminder(
                            serviceName = entry.serviceType ?: "Service",
                            reminderText = "Reminder: ${entry.rawText} is scheduled for tomorrow",
                            notificationId = (entry.id + "_1day").hashCode()
                        )
                    }
                    
                    // Show notification on the day (at 8 AM or if overdue)
                    if (timeUntilReminder <= oneHourInMillis && timeUntilReminder >= -oneHourInMillis) {
                        notificationManager.showServiceReminder(
                            serviceName = entry.serviceType ?: "Service",
                            reminderText = "Today: ${entry.rawText}",
                            notificationId = (entry.id + "_today").hashCode()
                        )
                    }
                }
            }
            
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

