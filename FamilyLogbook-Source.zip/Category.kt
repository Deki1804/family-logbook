package com.familylogbook.app.domain.model

enum class Category {
    HEALTH,
    SLEEP,
    MOOD,
    DEVELOPMENT,
    KINDERGARTEN_SCHOOL,
    HOME,
    FEEDING,
    OTHER
}

