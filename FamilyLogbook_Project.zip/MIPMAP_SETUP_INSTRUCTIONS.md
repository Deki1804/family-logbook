# Kako napraviti Mipmap ikone u Android Studio

## Korak 1: Otvori Image Asset Studio
1. U Android Studio, desni klik na `app` folder u Project view-u
2. Odaberi: **New > Image Asset**
   - Ili: **File > New > Image Asset**

## Korak 2: Konfiguriraj ikone
1. **Asset Type:** Odaberi "Launcher Icons (Adaptive and Legacy)"
2. **Path:** Klikni na folder ikonu i odaberi:
   ```
   app/src/main/res/drawable/app_logo.png
   ```
3. **Name:** Ostavi `ic_launcher` (default)
4. **Foreground Layer:**
   - **Source Asset:** Odaberi `app_logo.png`
   - **Scaling:** Možeš podesiti ako treba
   - **Shape:** Odaberi "None" ili "Circle" (kako želiš)
5. **Background Layer:**
   - Možeš ostaviti prazno ili dodati pozadinsku boju
6. **Legacy Icon:**
   - ✅ Označi "Generate" za sve density verzije

## Korak 3: Preview i Generate
1. Pregledaj kako izgleda u Preview panelu
2. Klikni **Next**
3. Klikni **Finish**

## Rezultat
Android Studio će automatski kreirati:
- `mipmap-mdpi/ic_launcher.png` (48x48)
- `mipmap-hdpi/ic_launcher.png` (72x72)
- `mipmap-xhdpi/ic_launcher.png` (96x96)
- `mipmap-xxhdpi/ic_launcher.png` (144x144)
- `mipmap-xxxhdpi/ic_launcher.png` (192x192)
- I round verzije za sve density-je

## Napomena
- Slika `app_logo.png` je već postavljena u `drawable` folderu
- AndroidManifest.xml već koristi `@mipmap/ic_launcher` i `@mipmap/ic_launcher_round`
- Nakon što generiraš mipmap ikone, sve će raditi automatski!

