package com.familylogbook.app.domain.model

enum class Mood {
    VERY_BAD,
    BAD,
    NEUTRAL,
    GOOD,
    VERY_GOOD
}

